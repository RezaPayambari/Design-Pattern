package adesso.visitor.element.concrete;

import adesso.visitor.element.CarElement;
import adesso.visitor.visitor.CarElementVisitor;

public class Body implements CarElement {
	public void accept(CarElementVisitor visitor) {
		// TODO: Visit the Body;
	}
}
