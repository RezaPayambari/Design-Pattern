package adesso.facade.hometheater;

public class HomeTheaterFacade {

	public HomeTheaterFacade() {

	}

	/**
	 * Starts the poper, dims the light to 10, downs the screens, turns the
	 * projector on and put it in wide screen mode, turn the amplifier on, sets
	 * the dvd and the surround sound with a volumen level 5, turn the dvd on
	 * and finally plays the dvd.
	 * 
	 * @param movie
	 */
	public void watchMovie(String movie) {
		System.out.println("Get ready to watch a movie...");

	}

	/**
	 * Turns off the popper, turns on the ligth, the screen is going up, the
	 * projector is turned off, the amplifier toom, the dvd is stopped and
	 * ejected and turned off.
	 */
	public void endMovie() {
		System.out.println("Shutting movie theater down...");

	}

	/**
	 * Turn the lights and the amplifier on, sets the volume level to 5, insert
	 * the cd and choose stereo sound, turns the cd on and plays the title
	 * 
	 * @param cdTitle
	 */
	public void listenToCd(String cdTitle) {
		System.out.println("Get ready for an audiopile experence...");

	}

	/**
	 * Turns the amplifier off, sets the cd, ejects the cd and turns the cd off
	 */
	public void endCd() {
		System.out.println("Shutting down CD...");

	}

	/**
	 * Turns the tuner on, setst the frequency, turns the amplifier on, sets the
	 * volume level and set the amplifier to tuner
	 * 
	 * @param frequency
	 */
	public void listenToRadio(double frequency) {
		System.out.println("Tuning in the airwaves...");

	}

	/**
	 * Turns of the tuner and the amplifier
	 */
	public void endRadio() {
		System.out.println("Shutting down the tuner...");

	}
}
