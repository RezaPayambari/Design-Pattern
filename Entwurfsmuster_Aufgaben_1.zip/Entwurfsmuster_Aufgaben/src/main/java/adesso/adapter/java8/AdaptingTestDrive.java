package adesso.adapter.java8;

public class AdaptingTestDrive {

	public static void main(String[] args) {
		// 1. Pass the adapting Interface to the testAdaption method with a test
		// String to be adapted
		// 2. Perform following checks:
		// 2a. Given String has a length of exactly 3 characters
		// 2b. Given String contains the character sequence elt
		// 2c. Given String has a character 'a' at position 3
	}

	private static void testAdaption(AdaptingInterface adaptingInterface, String stringToAdapt) {
		System.out.println("Adaption returns " + adaptingInterface.adapt(stringToAdapt));
	}

}
