package adesso.composite.menu;

public class Waitress {

	public Waitress(MenuComponent allMenus) {
		// TODO: Assign the the whole menu
	}

	public void printMenu() {
		// TODO: Print the whole menu
	}
}
