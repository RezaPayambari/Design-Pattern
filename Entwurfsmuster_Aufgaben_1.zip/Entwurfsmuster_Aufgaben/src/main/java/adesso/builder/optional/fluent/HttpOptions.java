package adesso.builder.optional.fluent;

public class HttpOptions {
	private int port;
	private String host;
	private boolean ssl;
	private String certPath;
	private boolean compressed;

	private HttpOptions(Builder builder) {
		// TODO: Im Konstruktor werden alle Felder, die im Builder gesetzt
		// wurden initialisiert
	}

	public static class Builder {
		// TODO: Der Builder enth�lt alle Attribute der HttpOptions und bietet
		// Methoden an diese zu setzen. Dabei wird immer eine Instanz des
		// Builders zur�ckgegeben um die fluent Schreibweise zu erm�glichen
	}
}
