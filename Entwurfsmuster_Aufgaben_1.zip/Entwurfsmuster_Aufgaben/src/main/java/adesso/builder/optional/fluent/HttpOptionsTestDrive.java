package adesso.builder.optional.fluent;

public class HttpOptionsTestDrive {

	public static void main(String[] args) {
		// TODO: Build a http option
		HttpOptions options = null;
		System.out.println(options);
	}

}
