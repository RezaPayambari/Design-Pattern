package adesso.factory.java8;

import java.util.function.Supplier;

/**
 * The generic <T> is just a place holder. You can infere the Generic by placing
 * a Java data type, e.g. Integer or your own implementation of a Salary object
 */
public class SalarySupplierFactory<T> {

	public SalarySupplierFactory(Supplier<T> factory) {
		// 1. Assign factory to a final variable
	}

	public T getSalary() {
		// Return the value of the factory
		return null;
	}
}
