package adesso.builder.builder.concrete;

import adesso.builder.builder.PizzaBuilder;

public class SpicyPizzaBuilder extends PizzaBuilder {

	@Override
	public void buildDough() {
		// TODO: Build dough of the spicy pizza ("pan baked")
	}

	@Override
	public void buildSauce() {
		// TODO: Build sauce of the hawaiian pizza ("hot")
	}

	@Override
	public void buildTopping() {
		// TODO: Build topping of the hawaiian pizza ("peppeorin+salami")
	}
}
