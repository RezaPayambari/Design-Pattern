package adesso.observer.weather;

public class WeatherData implements Subject {
	private float temperature;
	private float humidity;
	private float pressure;

	public WeatherData() {
	}

	public void registerObserver(Observer o) {
		// TODO: Register Observer
	}

	public void removeObserver(Observer o) {
		// TODO: Remove Observer when available
	}

	public void notifyObservers() {

		// TODO: Notify all observer and call update
	}

	public void measurementsChanged() {
		notifyObservers();
	}

	public void setMeasurements(float temperature, float humidity, float pressure) {
		this.temperature = temperature;
		this.humidity = humidity;
		this.pressure = pressure;
		measurementsChanged();
	}

	public float getTemperature() {
		return temperature;
	}

	public float getHumidity() {
		return humidity;
	}

	public float getPressure() {
		return pressure;
	}
}
