package adesso.builder.builder;

import adesso.builder.product.Pizza;

public abstract class PizzaBuilder {

	public Pizza getPizza() {
		// TODO: Return pizza
		return null;
	}

	public void createNewPizza() {
		// TODO: Implement creation of a new pizza here
	}

	public abstract void buildDough();

	public abstract void buildSauce();

	public abstract void buildTopping();

}
