package adesso.visitor.visitor.concrete;

import adesso.visitor.element.concrete.Body;
import adesso.visitor.element.concrete.Car;
import adesso.visitor.element.concrete.Engine;
import adesso.visitor.element.concrete.Wheel;
import adesso.visitor.visitor.CarElementVisitor;

public class CarElementPrintVisitor implements CarElementVisitor {
	public void visit(Wheel wheel) {
		System.out.println("Visiting " + wheel.getName() + " wheel");
	}

	public void visit(Engine engine) {
		System.out.println("Visiting engine");
	}

	public void visit(Body body) {
		System.out.println("Visiting body");
	}

	public void visit(Car car) {
		System.out.println("Visiting car");
	}
}
