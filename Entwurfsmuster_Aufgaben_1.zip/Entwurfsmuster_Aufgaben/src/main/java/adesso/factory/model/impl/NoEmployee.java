package adesso.factory.model.impl;

import adesso.factory.model.Employee;
import adesso.factory.model.EmployeeType;

public class NoEmployee extends Employee {

	@Override
	public EmployeeType getType() {
		return EmployeeType.NOEMPLOYEE;
	}
}
