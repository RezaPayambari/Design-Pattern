package adesso.observer.weather;

public class CurrentConditionsDisplay implements DisplayElement {
	private float temperature;
	private float humidity;

	public CurrentConditionsDisplay(Subject weatherData) {
		// TODO: Register this as observer
	}

	// TODO: Update: Set given temperature and humidity and display

	public void display() {
		System.out.println("Current conditions: " + temperature + "F degrees and " + humidity + "% humidity");
	}
}
