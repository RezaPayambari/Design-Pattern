package adesso.factory.factory;

import adesso.factory.model.EmployeeType;

public class SalaryFactory {

	/**
	 * Return the salary depending on the employee type
	 * 
	 * Student salary = 10000, Trainee salary = 20000, Junior salary = 40000,
	 * Senior salary = 65000, Boss salary = 125000, No employee = 0
	 * 
	 * @param type
	 *            - The kind of employee
	 * @return The salary according to the {@link EmployeeType}
	 */
	public static int getSalary(EmployeeType type) {
		// TODO: Implement the factory
		// TODO: Calculate the salary depending on the EmployeeType
		// TODO: Optional: Create an interface for salaries and return concrete
		// Salary implementations instead of returning just an integer value
		return 0;
	}
}
