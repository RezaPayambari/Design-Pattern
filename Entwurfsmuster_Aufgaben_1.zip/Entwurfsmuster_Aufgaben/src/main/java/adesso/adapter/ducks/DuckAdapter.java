package adesso.adapter.ducks;

public class DuckAdapter implements Turkey {

	public DuckAdapter(Duck duck) {
	}

	public void gobble() {
	}

	public void fly() {
	}
}
