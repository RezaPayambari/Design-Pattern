package adesso.strategy.quackbehavior;

public interface QuackBehavior {
	public void quack();
}
