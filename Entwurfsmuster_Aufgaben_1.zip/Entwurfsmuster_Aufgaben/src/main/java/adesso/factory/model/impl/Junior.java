package adesso.factory.model.impl;

import adesso.factory.model.Employee;
import adesso.factory.model.EmployeeType;

public class Junior extends Employee {

	@Override
	public EmployeeType getType() {
		return EmployeeType.JUNIOR;
	}

}
