package adesso.factory;

public class EmployeeTestDrive {

	public static void main(String[] args) {
		// TODO: Instantiate a student
		// TODO: Get the student salary
		int studentSalary = 0;
		System.out.println("As a student you will earn " + studentSalary + " � a year");

		// TODO: Instantiate a boss
		// TODO: Get the boss salary
		int bossSalary = 0;
		System.out.println("As a boss you will earn " + bossSalary + " � a year");
	}

}
