package adesso.strategy.duck;

// TODO: Make this class abstract
public interface Duck {

	// TODO: Provide setter for changing the fly and quack behavior
	// TODO: Provide methods for quacking and flying which delegate the call to
	// the concrete fly and quck implementation

	// TODO: Make this method abstract
	public void display();

	// TODO: Implement this method because all ducks can swim
	public void swim();
}
