package adesso.builder;

import adesso.builder.director.Waiter;
import adesso.builder.product.Pizza;

public class PizzaBuilderExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Waiter waiter = new Waiter();

		// TODO: Implement concrete pizza builder

		// TODO : Assign concrete pizza builder to waiter and let him construct
		// the pizza

		Pizza pizza = waiter.getPizza();

		System.out.println("Yummy pizza with a " + pizza.getDough() + " crust a " + pizza.getSauce() + " sauce and "
				+ pizza.getTopping() + " as topping");

	}

}
