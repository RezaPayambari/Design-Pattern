package adesso.observer.weather;

public class StatisticsDisplay implements DisplayElement {
	private float maxTemp = 0.0f;
	private float minTemp = 200;
	private float tempSum = 0.0f;
	private int numReadings;

	public StatisticsDisplay(WeatherData weatherData) {
		// TODO: Register this as observer
	}

	// TODO: Update: Sum the given temperature to tempSum and increase the
	// numReadings by 1. If the given temperature is higher than maxTemp then
	// set maxTemp to given temperature. If the given temperature is lower than
	// minTemp set the minTemp to the given temperature and display

	public void display() {
		System.out.println("Avg/Max/Min temperature = " + (tempSum / numReadings) + "/" + maxTemp + "/" + minTemp);
	}
}
