package adesso.adapter.java8;

@FunctionalInterface
public interface AdaptingInterface {
	public Boolean adapt(String s);
}
