package adesso.composite.menu;

public class Menu {
	String name;
	String description;

	public Menu(String name, String description) {
		this.name = name;
		this.description = description;
	}

	public void add(MenuComponent menuComponent) {
		// TODO: Add the menuComponent
	}

	public void remove(MenuComponent menuComponent) {
		// TODO: Remove the menuComponent
	}

	public MenuComponent getChild(int i) {
		// TODO: Return the child at the given index
		return null;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public void print() {
		System.out.print("\n" + getName());
		System.out.println(", " + getDescription());
		System.out.println("---------------------");

		// TODO: Iterate over the menuComponents and print the menu
	}
}
