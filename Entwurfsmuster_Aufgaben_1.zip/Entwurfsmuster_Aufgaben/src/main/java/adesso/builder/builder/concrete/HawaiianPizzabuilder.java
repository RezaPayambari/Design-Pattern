package adesso.builder.builder.concrete;

import adesso.builder.builder.PizzaBuilder;

public class HawaiianPizzabuilder extends PizzaBuilder {

	@Override
	public void buildDough() {
		// TODO: Build dough of the hawaiian pizza ("cross")
	}

	@Override
	public void buildSauce() {
		// TODO: Build sauce of the hawaiian pizza ("mild")
	}

	@Override
	public void buildTopping() {
		// TODO: Build topping of the hawaiian pizza ("hamp+pineapple")
	}
}
