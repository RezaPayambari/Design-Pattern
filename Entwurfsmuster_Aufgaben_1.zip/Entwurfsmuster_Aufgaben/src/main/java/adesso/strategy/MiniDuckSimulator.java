package adesso.strategy;

import adesso.strategy.duck.DecoyDuck;
import adesso.strategy.duck.MallardDuck;
import adesso.strategy.duck.ModelDuck;
import adesso.strategy.duck.RubberDuck;

public class MiniDuckSimulator {

	public static void main(String[] args) {

		MallardDuck mallard = new MallardDuck();
		RubberDuck rubberDuckie = new RubberDuck();
		DecoyDuck decoy = new DecoyDuck();

		ModelDuck model = new ModelDuck();

		mallard.quack();
		rubberDuckie.quack();
		decoy.quack();

		model.fly();
	}
}
