package adesso.factory.model;

public abstract class Employee {

	// TODO: Optional: Add a salary via composition

	// TODO: Optional: Implement getter and setters for salary

	// TODO: Optional: Implement a method which gets the final salary from the
	// given
	// salary object

	public abstract EmployeeType getType();
}
