package adesso.visitor.visitor.concrete;

import adesso.visitor.element.concrete.Body;
import adesso.visitor.element.concrete.Car;
import adesso.visitor.element.concrete.Engine;
import adesso.visitor.element.concrete.Wheel;
import adesso.visitor.visitor.CarElementVisitor;

public class CarElementDoVisitor implements CarElementVisitor {
	public void visit(Wheel wheel) {
		System.out.println("Kicking my " + wheel.getName() + " wheel");
	}

	public void visit(Engine engine) {
		System.out.println("Starting my engine");
	}

	public void visit(Body body) {
		System.out.println("Moving my body");
	}

	public void visit(Car car) {
		System.out.println("Starting my car");
	}
}
