package adesso.strategy.flybehavior;

public interface FlyBehavior {
	public void fly();
}
