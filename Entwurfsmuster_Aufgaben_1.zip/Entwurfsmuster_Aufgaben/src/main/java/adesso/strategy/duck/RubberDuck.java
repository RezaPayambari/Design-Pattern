package adesso.strategy.duck;

import adesso.strategy.flybehavior.FlyBehavior;
import adesso.strategy.quackbehavior.QuackBehavior;

public class RubberDuck implements Duck, FlyBehavior, QuackBehavior {
	// TODO: This implementation should extend the Duck and during object
	// initialization set the Fly and QuackBehavior (be aware of the both
	// interfaces. Do you need them?)
	// A red head Duck has "Squeak" as quackbehavior and "I can't fly" as fly
	// behavior. Use simple System.out.println for the behaviors
	public RubberDuck() {

	}

	public void display() {
		System.out.println("I'm a rubber duckie");
	}

	public void swim() {
		System.out.println("All ducks float, even decoys!");
	}

	@Override
	public void quack() {
		System.out.println("Squeak");
	}

	@Override
	public void fly() {
		System.out.println("I can't fly");
	}
}
