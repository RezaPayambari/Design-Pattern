package adesso.builder.director;

import adesso.builder.builder.PizzaBuilder;
import adesso.builder.product.Pizza;

public class Waiter {

	public void setPizzaBuilder(PizzaBuilder builder) {
		// TODO: Implement logic here
	}

	public Pizza getPizza() {
		// TODO: Return pizza
		return null;
	}

	public void constructPizza() {
		// TODO: Implement construction of a pizza here
	}
}
