package adesso.visitor.element.concrete;

import adesso.visitor.element.CarElement;
import adesso.visitor.visitor.CarElementVisitor;

public class Car implements CarElement {
	CarElement[] elements;

	public Car() {
		// TODO: create new Array of elements consisting of four wheels, one
		// body, one engine
		this.elements = new CarElement[] {};
	}

	public void accept(CarElementVisitor visitor) {
		// TODO: traverse over the car elements and visit the objects

		// TODO: Visit the car, too
	}
}
