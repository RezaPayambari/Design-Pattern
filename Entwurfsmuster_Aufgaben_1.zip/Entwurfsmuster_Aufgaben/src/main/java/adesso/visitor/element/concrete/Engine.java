package adesso.visitor.element.concrete;

import adesso.visitor.element.CarElement;
import adesso.visitor.visitor.CarElementVisitor;

public class Engine implements CarElement {
	public void accept(CarElementVisitor visitor) {
		// TODO: Visit the Engine
	}
}
