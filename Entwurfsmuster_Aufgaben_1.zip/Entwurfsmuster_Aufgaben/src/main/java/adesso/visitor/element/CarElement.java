package adesso.visitor.element;

import adesso.visitor.visitor.CarElementVisitor;

public interface CarElement {
	void accept(CarElementVisitor visitor); // CarElements have to provide
	// accept().
}
