package adesso.adapter.ducks;

public class TurkeyAdapter implements Duck {

	public TurkeyAdapter(Turkey turkey) {
	}

	public void quack() {
	}

	public void fly() {
	}
}
