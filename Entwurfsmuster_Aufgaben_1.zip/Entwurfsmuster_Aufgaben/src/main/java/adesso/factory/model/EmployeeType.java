package adesso.factory.model;

public enum EmployeeType {
	NOEMPLOYEE, STUDENT, TRAINEE, JUNIOR, SENIOR, BOSS;
}
